def add_client_tag():
    """stub; does nothing yet."""
def add_particle_emittor(spaceObject, lifeSpan, descriptorString):
    """creates a complex particle emittor and attaches it to a space object."""
def app_milliseconds():
    ...
def app_minutes():
    ...
def app_seconds():
    ...
def assign_client_to_alt_ship(clientComputerID, controlledShipID):
    """Tells a client computer that the 2d radar should focus on controlledShipID, instead of its assigned ship.  Turn this code off by providing zero as the second argument."""
def assign_client_to_ship(clientComputerID, controlledShipID):
    """Tells a client computer which ship it should control."""
def broad_test(lx, lz, mx, mz, abits):
    """return a list of space objects that are currently inside an x/z 2d rect  ARGS, and bitfield"""
def cinematic_control(clientID, scriptControlsCamera, dollyID, dollyPos, targetID, targetPos):
    """for a specific client (0=server machine), this sets the values to be used with the 'cinematic' console, which requiers a 3d_view widget, and 'cinematic' == camModeTag"""
def clear_client_tags():
    """stub; does nothing yet."""
def create_new_sim():
    """all space objects are deleted; a blank slate is born."""
def delete_all_navpoints():
    """deletes all navpoints on server, and notifies all clients of the change"""
def delete_grid_object(spaceObjectID, gridObjID):
    """deletes the grid object, and sends the deletion message to all clients"""
def delete_object(ID):
    """deletes a space object by its ID"""
def delete_particle_emittor(emittorID):
    """deletes a particle emittor by ID."""
def distance(arg0, arg1):
    """returns the distance between two space objects; arguments are two spaceObjects"""
def distance_between_navpoints(arg0, arg1):
    """returns the distance between two nav points; navpoints by ID"""
def distance_id(arg0, arg1):
    """returns the distance between two space objects; arguments are two IDs"""
def distance_point_line(arg0, arg1, arg2):
    """calulates the distance from a point to a line, for checking potential collisions. Returns a tuple, containing: distance to collision pt along line; distance from line start to point; tangent (positive == in front"""
def distance_to_navpoint(arg0, arg1):
    """returns the distance between a nav point and a space object; navpoint ID, then object ID"""
def find_valid_grid_point_for_vector3(spaceObjectID, vecPoint, randomRadius):
    """return a list of two integers, the grid x and y that is open and is closest.  The list is empty if the search fails."""
def find_valid_unoccupied_grid_point_for_vector3(spaceObjectID, vecPoint, randomRadius):
    """return a list of two integers, the grid x and y that is open and is closest.  The list is empty if the search fails."""
def get_client_ID_list():
    """return a list of client ids, for the computers that are currently connected to this server."""
def get_debug_gui_tree(clientID, tag, displayListFlag):
    """sends a GUI debug message from the targeted client (0 = server screen)"""
def get_game_version():
    """returns the version of the game EXE currently operating this script, as a string."""
def get_hull_map(spaceObjectID, forceCreate):
    """gets the hull map object for this space object; setting forceCreate to True will erase and rebuild the grid (and gridObjects) of this spaceobject"""
def get_preference_float(key):
    """Gets a value from preferences.json"""
def get_preference_int(key):
    """Gets a value from preferences.json"""
def get_preference_string(key):
    """Gets a value from preferences.json"""
def get_screen_size():
    """returns a VEC2, with the width and height of the display in pixels"""
def get_shared_string(key):
    """gets a shared string, given the key (itself a string).  Shared strings are automatically copied from server to all clients."""
def get_ship_of_client(clientID):
    """returns the player ship ID assigned to the client computer"""
def get_text_block_height(fontTag, textToMeasure, width):
    """for a font key, a string of (possibly) multiline text, and a pixel width, this returns the height of the drawn text."""
def get_text_line_height(fontTag, textToMeasure):
    """for a font key and a text string (one line, no wrapping), this returns the height of the drawn text."""
def get_text_line_width(fontTag, textToMeasure):
    """for a font key and a text string (one line, no wrapping), this returns the width of the drawn text."""
def get_type_of_client(clientID):
    """returns the consoleType perviously assigned to the client computer"""
def hide_gui_tag(clientID, tag):
    """makes a GUI element invisible, on the targeted client (0 = server screen)"""
def in_standby_list(space_object):
    """returns true if the spaceobject is in the standby list."""
def in_standby_list_id(id):
    """returns true if the spaceobject is in the standby list."""
def is_demo():
    """Returns true if the EXE is marked as a demo version."""
def particle_at(position, descriptorString):
    """emit some particles in space."""
def particle_emittor_exists(emittorID):
    """checks for the existance of a particle emittor."""
def particle_on(spaceObject, descriptorString):
    """emit some particles in space from a space object."""
def pause_sim():
    """the sim will now pause; HandlePresentGUI() and HandlePresentGUIMessage() are called."""
def play_audio_file(clientID, filename, volume, pitch):
    """Plays a WAV audio file now, for just the specified client, OR zero for server."""
def play_music_file(ID, filename):
    """Plays a music file now; ID is ship, OR client, OR zero for server."""
def player_ship_setup_defaults(space_object):
    """Rebuilds the default blob data of this player ship."""
def player_ship_setup_from_data(space_object):
    """Rebuilds the blob data of this player ship from the shipdata.json and the preferences.json."""
def push_to_standby_list(space_object):
    """moves the spaceobject from normal space to the standby list."""
def push_to_standby_list_id(id):
    """moves the spaceobject from normal space to the standby list."""
def query_client_tags():
    """stub; does nothing yet."""
def query_client_widget_state(clientID, widgetName, fullScreenFlag):
    """sends a request for the client to send a 'widget_box_state' script event back."""
def remove_gui_hotkey(clientID, tag):
    """tells the targeted client (0 = server screen) to delete an existing hot key for a certain retained gui element."""
def request_client_string(clientComputerID, string_key):
    """requests a string value from the client computer.  This results in a script message, 'client_string'"""
def resume_sim():
    """the sim will now run; HandleStartMission() and HandleTickMission() are called."""
def retrieve_from_standby_list(space_object):
    """moves the spaceobject from the standby list to normal space."""
def retrieve_from_standby_list_id(id):
    """moves the spaceobject from the standby list to normal space."""
def run_next_mission(mission_folder):
    """Shuts down this script and starts the mission in the folder argument"""
def send_client_widget_list(clientID, consoleType, widgetList):
    """sends the gameplay widgets to draw, on the targeted client (0 = server screen)"""
def send_client_widget_rects(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9):
    """changes the rects of a gameplay widget, on the targeted client (0 = server screen)."""
def send_comms_button_info(arg0, arg1, arg2, arg3):
    """sends a complex message to the comms console of a certain ship. args), std, std:string bodyText"""
def send_comms_message_to_player_ship(playerID, otherID, faceDesc, titleText, titleColor, bodyText, bodyColor):
    """sends a complex message to the comms console of a certain ship. args), uint64 otherID, std, std, std, std:string bodyColor"""
def send_comms_selection_info(arg0, arg1, arg2, arg3):
    """sends a complex message to the comms console of a certain ship. args), std, std:string bodyText"""
def send_grid_button_info(arg0, arg1, arg2, arg3):
    """sends a complex message to the engineering console of a certain ship. args), std, std:string bodyText"""
def send_grid_selection_info(arg0, arg1, arg2, arg3):
    """sends a complex message to the engineering console of a certain ship. args), std, std:string bodyText"""
def send_gui_3dship(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a 3D ship box GUI element, on the targeted client (0 = server screen)"""
def send_gui_button(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a button GUI element, on the targeted client (0 = server screen)"""
def send_gui_checkbox(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a checkbox GUI element, on the targeted client (0 = server screen)"""
def send_gui_clear(clientID, tag):
    """Clears all GUI elements from screen, on the targeted client (0 = server screen).  remember to use send_gui_complete after adding widgets."""
def send_gui_clickregion(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a click-region GUI element, on the targeted client (0 = server screen)"""
def send_gui_colorbutton(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a color button GUI element, on the targeted client (0 = server screen)"""
def send_gui_colorcheckbox(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a color checkbox GUI element, on the targeted client (0 = server screen)"""
def send_gui_complete(clientID, tag):
    """Flips double-buffered GUI display list, on the targeted client (0 = server screen).  Use after a send_gui_clear() and some send_gui* calls"""
def send_gui_dropdown(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a dropdown GUI element, on the targeted client (0 = server screen)"""
def send_gui_face(clientID, parent, tag, face_string, left, top, right, bottom):
    """Creates a face box GUI element, on the targeted client (0 = server screen)"""
def send_gui_hotkey(clientID, category, tag, keyType, description):
    """tells the targeted client (0 = server screen) to handle a hot key for a certain retained gui element."""
def send_gui_icon(clientID, parent, tag, style, left, top, right, bottom):
    """Creates an icon art GUI element, on the targeted client (0 = server screen)"""
def send_gui_iconbutton(clientID, parent, tag, style, left, top, right, bottom):
    """Creates an icon-button GUI element, on the targeted client (0 = server screen)"""
def send_gui_iconcheckbox(clientID, parent, tag, style, left, top, right, bottom):
    """Creates an icon-checkbox GUI element, on the targeted client (0 = server screen)"""
def send_gui_image(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a 2d art image GUI element, on the targeted client (0 = server screen)"""
def send_gui_rawiconbutton(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a simple clickable icon GUI element, on the targeted client (0 = server screen)"""
def send_gui_slider(clientID, parent, tag, current, style, left, top, right, bottom):
    """Creates a slider bar GUI element, on the targeted client (0 = server screen) (long clientID, std, float low, float high, float current, float left, float top, float right, float bottom, bool showNumberFlag)"""
def send_gui_sub_region(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a subregion GUI element, on the targeted client (0 = server screen)"""
def send_gui_text(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a text box GUI element, on the targeted client (0 = server screen)"""
def send_gui_typein(clientID, parent, tag, style, left, top, right, bottom):
    """Creates a text entry GUI element, on the targeted client (0 = server screen)"""
def send_message_to_client(clientID, colorDesc, text):
    """sends a text message to the text box, for the specific client. args), std, std:string text"""
def send_message_to_player_ship(playerID, colorDesc, text):
    """sends a text message to the text box, on every client for a certain ship. args), std, std:string text"""
def send_speech_bubble_to_object(clientComputerID, spaceObjectID, seconds, color, text):
    """attaches a speech bubble to a space object on the 2d radar."""
def send_story_dialog(clientID, title, text, face, color):
    """sends a story dialog to the targeted client (0 = server screen)"""
def set_beam_damages(clientID, playerBeamDamage, npcBeamDamage):
    """sets the values for player base beam damage, and npc base beam damage.  Per client, or all clients + server (if ID = 0)."""
def set_client_string(clientComputerID, string_key, string_value):
    """stores a string value (and its string key) to the client computer"""
def set_dmx_channel(clientID, channel, behavior, speed, low, high):
    """set a color channel of dmx."""
def set_main_view_modes(clientID, main_screen_view, cam_angle, cam_mode):
    """sets the three modes of the main screen view for the specified client.  main_screen_view = (3d_view, info, data);  cam_angle = (front, back, left, right); cam_mode = (first_person, chase, tracking)"""
def set_music_folder(ID, filename):
    """Sets the folder from which music is streamed; ID is ship, OR client, OR zero for server."""
def set_music_tension(ID, tensionValue):
    """Sets the tension value of ambient music (0-100); ID is ship, OR client, OR zero for server."""
def set_shared_string(key, value):
    """sets (or changes) a shared string, given a key and a value (both strings).  The shared strings are automatically copied from server to all clients."""
def set_sky_box(clientID, artFileName):
    """sets the skybox art for a clientID (0 = server)."""
def set_sky_box_all(artFileName):
    """sets the skybox art for all connected computers."""
def show_gui_tag(clientID, tag):
    """makes a GUI element visible, on the targeted client (0 = server screen)"""
def super_hyper_warp_mode(clientID, ship_hull_key, on_off_flag):
    """turns on (or off) the super_hyper_warp_mode screen to a particular computer"""
def suppress_client_connect_dialog(on_off_flag):
    """turns on (or off) the client connect dialog on the server (arg is 1 or 0)"""
def transparent_options_button(clientID, on_off_flag):
    """for a specific client (0=server machine), turns on (or off) the Options button transparency (arg is 1 or 0)"""
class SHPSYS(object): ### from pybind
    """One of four ship systems to track damage
    
    Members:
    
      WEAPONS : the weapons index for *system_damage*
    
      ENGINES : the engines index for *system_damage*
    
      SENSORS : the sensors index for *system_damage*
    
      SHIELDS : the shields index for *system_damage*
    
      MAX : the total number of types of *system_damage*"""
    def __eq__(self, other):
        ...
    def __getstate__(self):
        ...
    def __hash__(self):
        ...
    def __index__(self):
        ...
    def __init__(self, value):
        ...
    def __int__(self):
        ...
    def __ne__(self, other):
        ...
    def __repr__(self):
        ...
    def __setstate__(self, state):
        ...
    def __str__(*argv):
        """name(self) -> str"""
        ...
    @property
    def name(self):
        """name(self) -> str"""
        ...
    @property
    def value (arg0):
        ...
class Writer(object): ### from pybind
    """class Writer"""
    def flush(self):
        ...
    def write(self, arg0):
        ...
class event(object): ### from pybind
    """class event"""
    @property
    def client_id (self):
        """id of computer this event came from."""
        ...
    @property
    def event_time (self):
        """long int, time this damage occured, compare to simulation.time_tick_counter"""
        ...
    @property
    def extra_extra_tag (self):
        """string, even more-more information"""
        ...
    @property
    def extra_tag (self):
        """string, even more information"""
        ...
    @property
    def origin_id (self):
        """id of space object this event came from"""
        ...
    @property
    def parent_id (self):
        """id of owner/creator of space object this event came from (like the ship that fired the missile)"""
        ...
    @property
    def selected_id (self):
        """id of space object this event is talking about, or doing something to"""
        ...
    @property
    def source_point (self):
        """vec3, 3d point this event originated from"""
        ...
    @property
    def sub_float (self):
        """float, numeric information"""
        ...
    @property
    def sub_tag (self):
        """string describing message sub-type"""
        ...
    @property
    def tag (self):
        """string describing message type"""
        ...
    @property
    def value_tag (self):
        """string, more information"""
        ...
class grid_object(object): ### from pybind
    """class grid_object"""
    @property
    def data_set (self):
        """object_data_set, read only, reference to the object_data_set of this particular grid object"""
        ...
    @property
    def layer (self):
        """int, layers to help draw different grid-objects correctly.  (recommend 0-8, with 0 being lowest)"""
        ...
    @layer.setter
    def layer (self, arg0):
        """int, layers to help draw different grid-objects correctly.  (recommend 0-8, with 0 being lowest)"""
        ...
    @property
    def name (self):
        """string, text name"""
        ...
    @name.setter
    def name (self, arg0):
        """string, text name"""
        ...
    @property
    def tag (self):
        """string, text tag"""
        ...
    @tag.setter
    def tag (self, arg0):
        """string, text tag"""
        ...
    @property
    def type (self):
        """string, text value, broad type of object"""
        ...
    @type.setter
    def type (self, arg0):
        """string, text value, broad type of object"""
        ...
    @property
    def unique_ID (self):
        """uint64, read only, id of this particular grid object"""
        ...
class hullmap(object): ### from pybind
    """class hullmap"""
    @property
    def art_file_root (self):
        """string, file name, used to get top-down image from disk"""
        ...
    @art_file_root.setter
    def art_file_root (self, arg0):
        """string, file name, used to get top-down image from disk"""
        ...
    def create_grid_object(self, name, tag, type):
        """returns a gridobject, after creating it"""
        ...
    @property
    def desc (self):
        """string, description text"""
        ...
    @desc.setter
    def desc (self, arg0):
        """string, description text"""
        ...
    def get_grid_object_by_id(self, id):
        """returns a gridobject, by uint64 ID"""
        ...
    def get_grid_object_by_index(self, index):
        """returns a gridobject, by position in the list"""
        ...
    def get_grid_object_by_name(self, name):
        """returns a gridobject, by name"""
        ...
    def get_grid_object_by_tag(self, tag):
        """returns a gridobject, by text tag"""
        ...
    def get_grid_object_count(self):
        """get the number of grid objects in the list, within this hullmap"""
        ...
    def get_objects_at_point(self, x, y):
        """returns a list of grid object IDs that are currently at the x/y point."""
        ...
    @property
    def grid_scale (self):
        """float, space between grid points"""
        ...
    @grid_scale.setter
    def grid_scale (self, arg0):
        """float, space between grid points"""
        ...
    @property
    def h (self):
        """int, total grid hieght"""
        ...
    @h.setter
    def h (self, arg0):
        """int, total grid hieght"""
        ...
    def is_grid_point_open(self, arg0, arg1):
        """is the x/y point within this hullmap open (traversable)? 0 == no"""
        ...
    @property
    def name (self):
        """string, text name"""
        ...
    @name.setter
    def name (self, arg0):
        """string, text name"""
        ...
    @property
    def symmetrical_flag (self):
        """int, non-zero if the map is symmetrical"""
        ...
    @symmetrical_flag.setter
    def symmetrical_flag (self, arg0):
        """int, non-zero if the map is symmetrical"""
        ...
    @property
    def w (self):
        """int, total grid width"""
        ...
    @w.setter
    def w (self, arg0):
        """int, total grid width"""
        ...
class navpoint(object): ### from pybind
    """class navpoint"""
    def SetColor(self, arg0):
        """use a string color description to set the color"""
        ...
    @property
    def color (self):
        """vec4, color on 2d radar"""
        ...
    @color.setter
    def color (self, arg0):
        """vec4, color on 2d radar"""
        ...
    @property
    def has_changed_flag (self):
        """int, if you change this navpoint, also set this flag to !0, so the server sends it down to the clients"""
        ...
    @has_changed_flag.setter
    def has_changed_flag (self, arg0):
        """int, if you change this navpoint, also set this flag to !0, so the server sends it down to the clients"""
        ...
    @property
    def pos (self):
        """vec3, position in space"""
        ...
    @pos.setter
    def pos (self, arg0):
        """vec3, position in space"""
        ...
    @property
    def text (self):
        """string, text label"""
        ...
    @text.setter
    def text (self, arg0):
        """string, text label"""
        ...
    @property
    def visibleToShip (self):
        """uint64, id of the only space object that can see this navpoint (0 = all)"""
        ...
    @visibleToShip.setter
    def visibleToShip (self, arg0):
        """uint64, id of the only space object that can see this navpoint (0 = all)"""
        ...
    @property
    def visibleToSide (self):
        """string, text side name of side that can see this navpoint"""
        ...
    @visibleToSide.setter
    def visibleToSide (self, arg0):
        """string, text side name of side that can see this navpoint"""
        ...
class object_data_set(object): ### from pybind
    """class object_data_set"""
    def get(*args, **kwargs):
        """Overloaded function.
        
        1. get(self, arg0, arg1) -> object
        
        Get a value, by name
        
        2. get(self, arg0, arg1) -> object
        
        Get a value, by ID"""
        ...
    def set(*args, **kwargs):
        """Overloaded function.
        
        1. set(self, tag, in, index, extraDocText) -> int
        
        Set an int value, by name
        
        2. set(self, tag, in, index, extraDocText) -> int
        
        Set an int64 value, by name
        
        3. set(self, tag, in, index, extraDocText) -> int
        
        Set a uint64 value, by name
        
        4. set(self, tag, in, index, extraDocText) -> int
        
        Set a float value, by name
        
        5. set(self, tag, in, index, extraDocText) -> int
        
        Set a string value, by name
        
        6. set(self, arg0, arg1, arg2) -> int
        
        Set an int value, by ID
        
        7. set(self, arg0, arg1, arg2) -> int
        
        Set an int64 value, by ID
        
        8. set(self, arg0, arg1, arg2) -> int
        
        Set a uint64 value, by ID
        
        9. set(self, arg0, arg1, arg2) -> int
        
        Set a float value, by ID
        
        10. set(self, arg0, arg1, arg2) -> int
        
        Set a string value, by ID"""
        ...
class quaternion(object): ### from pybind
    """class quaternion"""
    def __init__(*args, **kwargs):
        """Overloaded function.
        
        1. __init__(self, arg0, arg1, arg2, arg3) -> None
        
        2. __init__(self, arg0) -> None
        
        3. __init__(self) -> None"""
        ...
    @property
    def w (self):
        """float, component value"""
        ...
    @w.setter
    def w (self, arg0):
        """float, component value"""
        ...
    @property
    def x (self):
        """float, component value"""
        ...
    @x.setter
    def x (self, arg0):
        """float, component value"""
        ...
    @property
    def y (self):
        """float, component value"""
        ...
    @y.setter
    def y (self, arg0):
        """float, component value"""
        ...
    @property
    def z (self):
        """float, component value"""
        ...
    @z.setter
    def z (self, arg0):
        """float, component value"""
        ...
class simulation(object): ### from pybind
    """class simulation"""
    def AddTractorConnection(self, arg0, arg1, arg2, arg3):
        """makes a new connection between two space objects.  Args, u64 targetID, sbs, float pullDistance"""
    def ClearTractorConnections(self):
        """destroys all existing tractor connections right now."""
    def DeleteTractorConnection(self, arg0, arg1):
        """finds and deletes an existing tractor connection.  Args, u64 targetID"""
    def GetTractorConnection(self, arg0, arg1):
        ...
    def add_navarea(self, x1, y1, x2, y2, x3, y3, x4, y4, text, colDesc):
        """adds a new navarea to space; don't hold on to this Navpoint object in a global; keep the integer ID return value instead    args, std, std:string colorDesc"""
    def add_navpoint(self, x, y, z, text, colDesc):
        """adds a new navpoint to space; don't hold on to this Navpoint object in a global; keep the integer ID return value instead    args, float y, float z, std, std:string colorDesc"""
    def create_space_object(self, aiTag, dataTag, abits):
        """creates a new spaceobject. abits is a 16-bit bitfield for further defining the object.  bit 1, when set, means the object is unmoving and static."""
    def delete_navpoint_by_id(self, id):
        """deletes navpoint by its id"""
    def force_update_to_clients(self, spaceObjectID, playerShipID):
        """forces this space object to update its data to the clients attached to the playerShipID (all clients, if playerShipID is zero)"""
    def get_navpoint_by_id(self, id):
        """takes a string name, returns the associated Navpoint object"""
    def get_navpoint_id_by_name(self, text):
        """returns a navpoint ID, given its name as the argument"""
    def get_shield_hit_index(self, sourceShip, targetShip):
        """Given a source ship and a target ship, this returns the shield (index) that would be hit by a hypothetical beam. -1 if the target ship has no shield facings."""
    def get_shield_hit_index_source(self, sourcePoint, targetShip):
        """Given a source position (vec3) and a target ship, this returns the shield (index) that would be hit by a hypothetical beam. -1 if the target ship has no shield facings."""
    def get_space_object(self, arg0):
        """returns the reference to a spaceobject, by ID"""
    def is_not_paused(self):
        """returns True if the game is currently running."""
    def navpoint_exists(self, text):
        """returns true if the navpoint exists, by id"""
    def reposition_space_object(self, arg0, arg1, arg2, arg3):
        """immediately changes the position of a spaceobject"""
    def space_object_exists(self, arg0):
        """returns true if the spaceobject exists, by ID"""
    @property
    def time_tick_counter (self):
        """get current time value"""
        ...
class space_object(object): ### from pybind
    """class space_object"""
    @property
    def abits (self):
        """unsigned 16-bit bitfield for filtering.  bits 0-3 is reserved by c++. bit 0, if set, means that this object is unmoving and static (nebula, asteroid, black hole, etc)"""
        ...
    @abits.setter
    def abits (self, arg0):
        """unsigned 16-bit bitfield for filtering.  bits 0-3 is reserved by c++. bit 0, if set, means that this object is unmoving and static (nebula, asteroid, black hole, etc)"""
        ...
    @property
    def blink_state (self):
        """int, positive numbers are pulse delay, negative numbers are blink delay, 0 = normal, -1 = glow off"""
        ...
    @blink_state.setter
    def blink_state (self, arg0):
        """int, positive numbers are pulse delay, negative numbers are blink delay, 0 = normal, -1 = glow off"""
        ...
    @property
    def cur_speed (self):
        """float, speed of object"""
        ...
    @cur_speed.setter
    def cur_speed (self, arg0):
        """float, speed of object"""
        ...
    @property
    def data_set (self):
        """object_data_set, read only, refernce to the object_data_set of this particular object"""
        ...
    @property
    def data_tag (self):
        """string, name of data entry in shipData.json"""
        ...
    @data_tag.setter
    def data_tag (self, arg0):
        """string, name of data entry in shipData.json"""
        ...
    @property
    def exclusion_radius (self):
        """float, other objects cannot be closer to me than this distance"""
        ...
    @exclusion_radius.setter
    def exclusion_radius (self, arg0):
        """float, other objects cannot be closer to me than this distance"""
        ...
    @property
    def fat_radius (self):
        """float, radius of box for internal sorting calculations"""
        ...
    @fat_radius.setter
    def fat_radius (self, arg0):
        """float, radius of box for internal sorting calculations"""
        ...
    def forward_vector(self):
        """returns a vec3, a vector direction, related to which way the space object is oriented"""
        ...
    @property
    def pos (self):
        """vec3, position in space"""
        ...
    @pos.setter
    def pos (self, arg0):
        """vec3, position in space"""
        ...
    def right_vector(self):
        """returns a vec3, a vector direction, related to which way the space object is oriented"""
        ...
    @property
    def rot_quat (self):
        """quaternion, heading and orientation of this object"""
        ...
    @rot_quat.setter
    def rot_quat (self, arg0):
        """quaternion, heading and orientation of this object"""
        ...
    def set_behavior(self, arg0):
        """set name of behavior module
        current available behavior modules , npcship, asteroid, playership, station"""
        ...
    @property
    def side (self):
        """string, friendly to other objects on this same side; leave empty for 'no side'"""
        ...
    @side.setter
    def side (self, arg0):
        """string, friendly to other objects on this same side; leave empty for 'no side'"""
        ...
    @property
    def steer_pitch (self):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @steer_pitch.setter
    def steer_pitch (self, arg0):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @property
    def steer_roll (self):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @steer_roll.setter
    def steer_roll (self, arg0):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @property
    def steer_yaw (self):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @steer_yaw.setter
    def steer_yaw (self, arg0):
        """float, continuing change to heading and orientation of this object, over time"""
        ...
    @property
    def tick_type (self):
        """string, name of behavior module
        current available behavior modules , npcship, asteroid, playership, station"""
        ...
    @property
    def tick_type_ID (self):
        """int32, read only, internal representation of tick_type"""
        ...
    @property
    def unique_ID (self):
        """uint64, read only, id of this particular object"""
        ...
    def up_vector(self):
        """returns a vec3, a vector direction, related to which way the space object is oriented"""
        ...
class tractor_connection(object): ### from pybind
    """class tractor_connection"""
    @property
    def offset (self):
        """float, how much the target is pulled towards the offset every tick. 0 = infinite pull, target locked to boss"""
        ...
    @offset.setter
    def offset (self, arg0):
        """float, how much the target is pulled towards the offset every tick. 0 = infinite pull, target locked to boss"""
        ...
    @property
    def source_id (self):
        """int, ID of boss/master/major object"""
        ...
    @property
    def target_id (self):
        """int, ID of object that is attached to the other"""
        ...
class vec2(object): ### from pybind
    """class vec2"""
    def __add__(self, arg0):
        ...
    def __iadd__(self, arg0):
        ...
    def __imul__(self, arg0):
        ...
    def __init__(*args, **kwargs):
        """Overloaded function.
        
        1. __init__(self, arg0, arg1) -> None
        
        2. __init__(self, arg0) -> None
        
        3. __init__(self) -> None"""
        ...
    def __mul__(self, arg0):
        ...
    def __neg__(self):
        ...
    def __rmul__(self, arg0):
        ...
    @property
    def x (self):
        """float, component value"""
        ...
    @x.setter
    def x (self, arg0):
        """float, component value"""
        ...
    @property
    def y (self):
        """float, component value"""
        ...
    @y.setter
    def y (self, arg0):
        """float, component value"""
        ...
class vec3(object): ### from pybind
    """class vec3"""
    def __add__(self, arg0):
        ...
    def __iadd__(self, arg0):
        ...
    def __imul__(self, arg0):
        ...
    def __init__(*args, **kwargs):
        """Overloaded function.
        
        1. __init__(self, arg0, arg1, arg2) -> None
        
        2. __init__(self, arg0) -> None
        
        3. __init__(self) -> None"""
        ...
    def __mul__(self, arg0):
        ...
    def __neg__(self):
        ...
    def __rmul__(self, arg0):
        ...
    @property
    def x (self):
        """float, component value"""
        ...
    @x.setter
    def x (self, arg0):
        """float, component value"""
        ...
    @property
    def y (self):
        """float, component value"""
        ...
    @y.setter
    def y (self, arg0):
        """float, component value"""
        ...
    @property
    def z (self):
        """float, component value"""
        ...
    @z.setter
    def z (self, arg0):
        """float, component value"""
        ...
class vec4(object): ### from pybind
    """class vec4"""
    def __add__(self, arg0):
        ...
    def __iadd__(self, arg0):
        ...
    def __imul__(self, arg0):
        ...
    def __init__(*args, **kwargs):
        """Overloaded function.
        
        1. __init__(self, arg0, arg1, arg2, arg3) -> None
        
        2. __init__(self, arg0) -> None
        
        3. __init__(self) -> None"""
        ...
    def __mul__(self, arg0):
        ...
    def __neg__(self):
        ...
    def __rmul__(self, arg0):
        ...
    @property
    def a (self):
        """float, component value (0.0-1.0)"""
        ...
    @a.setter
    def a (self, arg0):
        """float, component value (0.0-1.0)"""
        ...
    @property
    def b (self):
        """float, component value (0.0-1.0)"""
        ...
    @b.setter
    def b (self, arg0):
        """float, component value (0.0-1.0)"""
        ...
    @property
    def g (self):
        """float, component value (0.0-1.0)"""
        ...
    @g.setter
    def g (self, arg0):
        """float, component value (0.0-1.0)"""
        ...
    @property
    def r (self):
        """float, component value (0.0-1.0)"""
        ...
    @r.setter
    def r (self, arg0):
        """float, component value (0.0-1.0)"""
        ...
